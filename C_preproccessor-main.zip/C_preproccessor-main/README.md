# C_preproccessor
Pre-proccessor instructs the compiler to do required pre-processing before the actual compilation

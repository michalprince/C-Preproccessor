//'tddyd'
#define \
   R 5
#define N/**/(5)
#define /**/ A/**/ 4+/**/5//fgfhf
#include<vadefs.h>
void f_main() {
	
	for (int i = 0; i <N; i++)
	{
		int N_TR,_t;
		//multiple
		printf('%d ', N * i + A); //gdadfa
		///dgaf
	}
}

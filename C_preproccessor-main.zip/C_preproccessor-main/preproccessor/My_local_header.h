//
//  Header.h
//  Preprocessor


/* All the following defines are legal defines, and your program should be able to cope with them. The empty-define is used in conditional preprocessing. */

#define DIV 2
# define MULT 20
#   define    MAX      100

